import { createBrowserRouter, RouterProvider } from "react-router-dom";
import Layout from "./Layout";
import PostMainPage from "./features/posts/PostsMainPage";
import SinglePostPage from "./features/posts/SinglePostPage";
import EditPostForm from "./features/posts/EditPostForm";

const router = createBrowserRouter([
  {
    path: "/",
    element: <Layout />,
    children: [
      {
        path: "",
        element: (
          <>
            <PostMainPage />
          </>
        ),
      },
      {
        path: "/posts/:postId",
        element: <SinglePostPage />,
      },
      {
        path: "/editPost/:postId",
        element: <EditPostForm />,
      },
    ],
  },
]);

function App() {
  return <RouterProvider router={router} />;
}

export default App;
