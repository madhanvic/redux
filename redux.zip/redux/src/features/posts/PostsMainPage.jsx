import AddPostForm from "./AddPostForm";
import PostList from "./PostsList";

const PostMainPage = () => {
  return (
    <>
      <AddPostForm />
      <PostList />
    </>
  );
};

export default PostMainPage;
